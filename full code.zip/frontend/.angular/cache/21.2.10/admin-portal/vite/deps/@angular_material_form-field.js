import {
  MatFormFieldModule
} from "./chunk-3ARNYC5G.js";
import {
  MAT_ERROR,
  MAT_FORM_FIELD,
  MAT_FORM_FIELD_DEFAULT_OPTIONS,
  MAT_PREFIX,
  MAT_SUFFIX,
  MatError,
  MatFormField,
  MatFormFieldControl,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatFormFieldDuplicatedHintError,
  getMatFormFieldMissingControlError,
  getMatFormFieldPlaceholderConflictError
} from "./chunk-GVFACTM6.js";
import "./chunk-UJN57LPV.js";
import "./chunk-VON75VBJ.js";
import "./chunk-PLJ2QXBA.js";
import "./chunk-GUGIMSVJ.js";
import "./chunk-OMMYBBFM.js";
import "./chunk-XA6252L2.js";
import "./chunk-AENBZ7RZ.js";
import "./chunk-N4DOILP3.js";
import "./chunk-77LYXNTR.js";
import "./chunk-QJR7XCP7.js";
import "./chunk-XLLXAXGH.js";
import "./chunk-MGSQ5MNU.js";
import "./chunk-7G6HUB5O.js";
import "./chunk-MFRHORPN.js";
import "./chunk-LDOV6J26.js";
import "./chunk-653BA2CK.js";
import "./chunk-I4WKHNXR.js";
import "./chunk-6KPM7Q5X.js";
import "./chunk-R7AJGQHG.js";
import "./chunk-J46EEYGT.js";
import "./chunk-4YCCEXQQ.js";
import "./chunk-U7EDC2PH.js";
export {
  MAT_ERROR,
  MAT_FORM_FIELD,
  MAT_FORM_FIELD_DEFAULT_OPTIONS,
  MAT_PREFIX,
  MAT_SUFFIX,
  MatError,
  MatFormField,
  MatFormFieldControl,
  MatFormFieldModule,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatFormFieldDuplicatedHintError,
  getMatFormFieldMissingControlError,
  getMatFormFieldPlaceholderConflictError
};
